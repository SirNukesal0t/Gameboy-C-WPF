﻿using System.Windows;

namespace Gameboy
{
    public partial class App : Application
    {
    }
}
